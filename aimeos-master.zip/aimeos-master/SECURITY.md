# Reporting a Vulnerability

If you think you found a security issue, please use the [Aimeos contact from](https://aimeos.org/contact#c198) and describe how the problem can be reproduced.
