<div class="col-md-4">
    <div class="sidebar-items">
        <div class="card my-4">
            <div class="card-header bg-dark text-white">
                <h4>Books Ctaegories</h4>
            </div>
            <div class="card-body">
                <ul class="ctg-list">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="ctg-item">
                        <a href="<?php echo e(route('category', $category->slug)); ?>" class="ctg-link d-block"><?php echo e($category->name); ?></a>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
        <div class="card my-3">
            <div class="card-header bg-dark text-white">
                <h4>Recent Books</h4>
            </div>
            <div class="card-body">
                <?php $__currentLoopData = $recent_books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="recent-book-list">
                    <a href="<?php echo e(route('book-details', $book->id)); ?>" class="d-flex flex-row mb-3">
                        <div class="book-img mr-2"><img src="<?php echo e($book->image_url); ?>" alt="" width="80"></div>
                        <div class="book-text">
                            <p><?php echo e($book->title); ?></p>
                            <small><i class="fas fa-clock"></i> <?php echo e($book->created_at->diffForHumans()); ?></small>
                        </div>
                    </a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\adones\Downloads\Online-Bookshop-with-laravel-master\resources\views/layouts/includes/side-bar.blade.php ENDPATH**/ ?>