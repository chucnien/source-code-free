<nav class="navbar navbar-expand-sm text-white navbar-white p-1 border-bottom" id="nav-top">
    <div class="container">
        <a href="<?php echo e(route('bookshop.home')); ?>" class="logo-img"></a>
        <button class="navbar-toggler" data-toggle="collapse" data-target="#nav-collapse">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="nav-collapse">
            <ul class="navbar-nav ">
                <li class="nav-item px-2 ">
                    <a href="<?php echo e(route('bookshop.home')); ?>" class="nav-link">Home</a>
                </li>
                <li class="nav-item px-2">
                    <a href="<?php echo e(route('all-books')); ?>" class="nav-link">Books</a>
                </li>
                <li class="nav-item px-2">
                    <a href="<?php echo e(route('discount-books')); ?>" class="nav-link">Discount's Book</a>
                </li>
                <li class="nav-item px-2">
                    <a href="#" class="nav-link">About</a>
                </li>
            </ul>
            <ul class="navbar-nav ml-auto">
                <?php if(Auth::check() == false): ?>
                    <li class="nav-item px-2">
                        <a href="<?php echo e(url('login')); ?>" class="nav-link text-danger"><i class="fas fa-user-lock"></i> Login</a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(url('register')); ?>" class="nav-link"><i class="fas fa-user"></i> Register</a>
                    </li>
                <?php else: ?>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle active" href="#" data-toggle="dropdown">
                            <span class="image-circle"><img src="<?php echo e(Auth::user()->image? Auth::user()->image_url:Auth::user()->default_img); ?>" width="30" alt=""></span>
                            <?php echo e(Auth::user()->name); ?>

                        </a>
                        <div class="dropdown-menu">
                            <?php if(Auth::user()->role->name == "Admin"): ?>
                                <a class="dropdown-item" href="<?php echo e(route('admin.home')); ?>">
                                    <i class="fas fa-user fa-sm fa-fw mr-2 text-muted"></i>
                                    Profile
                                </a>
                            <?php elseif(Auth::user()->role->name == "User"): ?>
                                <a class="dropdown-item" href="<?php echo e(route('user.home')); ?>">
                                    <i class="fas fa-user fa-sm fa-fw mr-2 text-muted"></i>
                                    Profile
                                </a>
                            <?php else: ?>
                                <a class="dropdown-item" href="#">
                                    <i class="fas fa-user fa-sm fa-fw mr-2 text-muted"></i>
                                    Profile
                                </a>
                            <?php endif; ?>
                            <a class="dropdown-item" href="<?php echo e(url('logout')); ?>">
                                <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-muted"></i>
                                Logout
                            </a>
                        </div>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>
<?php /**PATH C:\Users\adones\Downloads\Online-Bookshop-with-laravel-master\resources\views/layouts/includes/navbar.blade.php ENDPATH**/ ?>