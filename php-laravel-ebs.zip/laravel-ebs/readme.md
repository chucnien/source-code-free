# Online Elecitricity Billing System in PHP
------------------------------------------------------
### Technologies
- PHP >= 8
- MySQL Database
- Laravel 9 Framework
- Bootstrap

------------------------------------------------------
### Database Name
- ebs_db

------------------------------------------------------
### Database File Path
- ./database file/ebs_db.sql

------------------------------------------------------
### Admin Default Access

- **Email:** admin@mail.com
- **Password:** admin123

