<?php $__env->startSection('custom_css'); ?>
<style>
body>#app{
    height: 100%;
    width: 100%;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
}
body>#app>nav{
    width: 100%;
    border-radius: 0px;
}
body>#app>.container{
   flex-shrink: 1;
   flex-grow: 1;
   display: flex;
   align-items: center;
   justify-content: center
}
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="col-lg-7 col-md-8 col-sm-10 col-xs-12">
        <div class="card rounded-0 shadow text-reset">
            <div class="card-header">
                <div class="card-title h3 fw bolder my-2 text-center">Register</div>
            </div>

            <div class="card-body">
                <form class="form-horizontal" method="POST" action="<?php echo e(route('register')); ?>">
                    <?php echo e(csrf_field()); ?>


                    <div class="mb-3<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                        <label for="name" class="control-label">Name</label>

                        <div class="">
                            <input id="name" type="text" class="form-control rounded-0" name="name" value="<?php echo e(old('name')); ?>" required autofocus>

                            <?php if($errors->has('name')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('name')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="mb-3<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                        <label for="email" class="control-label">Email Address</label>

                        <div class="">
                            <input id="email" type="email" class="form-control rounded-0" name="email" value="<?php echo e(old('email')); ?>" required>

                            <?php if($errors->has('email')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('email')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="customerId" class="control-label">Connection Id</label>

                        <div class="">
                            <input id="customerId" type="text" class="form-control rounded-0" name="customerId" required>
                            <?php if($errors->has('customerId')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('customerId')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="address" class="control-label">Address</label>

                        <div class="">
                            <input id="address" type="text" class="form-control rounded-0" name="address" required>
                        </div>
                    </div>
                    <div class="mb-3<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                        <label for="password" class="control-label">Password</label>

                        <div class="">
                            <input id="password" type="password" class="form-control rounded-0" name="password" required>

                            <?php if($errors->has('password')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('password')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label for="password-confirm" class="control-label">Confirm Password</label>
                        <div class="">
                            <input id="password-confirm" type="password" class="form-control rounded-0" name="password_confirmation" required>
                        </div>
                    </div>

                    <div class="mb-3">
                        <div class="d-grid">
                            <button type="submit" class="btn btn-primary bg-gradient rounded-0">
                                Register
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\eLECTRA\resources\views/auth/register.blade.php ENDPATH**/ ?>