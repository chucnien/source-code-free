<!DOCTYPE html>
<html>
<head>
    <title>Success</title>
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <style>

        .suc{
            margin-top:100px;
            font-size: 30px;
        }
        div{
            width:50%;
        }
        .btn{
            margin-left: 100px;
        }
        .center{ 
            margin:auto;
        }
    </style>
</head>
<body>
    <div class="center">
       <p class="suc">Record Added Successfully   <br>
    <a href="<?php echo e(url('/admin')); ?>"><button type="submit" class="btn btn-primary">Go Back</button></a></p> 
    </div>
    
    
</body>
</html>